torch.utils.ffi
===============

.. currentmodule:: torch.utils.ffi
.. autofunction:: create_extension

